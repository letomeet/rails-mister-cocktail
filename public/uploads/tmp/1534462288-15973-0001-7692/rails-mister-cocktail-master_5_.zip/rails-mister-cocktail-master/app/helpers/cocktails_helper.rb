module CocktailsHelper
end
