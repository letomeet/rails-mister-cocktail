import AOS from 'aos';

AOS.init();

// Requiring CSS! Path is relative to ./node_modules
import 'aos/dist/aos.css';

console.log("Hello from AOS");
