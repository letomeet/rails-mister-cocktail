import 'bootstrap';
import '../components/select2';
import '../components/aos';
import { loadDynamicBannerText } from '../components/banner';

loadDynamicBannerText();
